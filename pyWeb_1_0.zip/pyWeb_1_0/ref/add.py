import firebase_admin
from firebase_admin import credentials, db

# กำหนด path ไฟล์ service account key (.json) ที่คุณดาวน์โหลดจาก Firebase Console
cred = credentials.Certificate("admin.json")

# กำหนดชื่อโปรเจคใน Firebase และเข้าถึง Realtime Database
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://database-iot-python-default-rtdb.asia-southeast1.firebasedatabase.app/'
})

# ดึง reference ของ node ใน database
ref = db.reference('/')

# ส่งข้อมูลเข้า Firebase Realtime Database
data = {"switch1": 0,"switch2":0,"switch3":0,"switch4":0}
ref.update(data)
