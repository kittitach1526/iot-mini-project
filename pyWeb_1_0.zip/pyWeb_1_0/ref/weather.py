import requests
import datetime 

# ดึงเวลาปัจจุบัน
current_time = datetime.datetime.now()

# แปลงเวลาเป็นรูปแบบที่ไม่รวม Millisecond
formatted_date = current_time.strftime("%Y-%m-%d")
formatted_time = current_time.strftime("%H:%M:%S")

def get_weather():
    url = "https://data.tmd.go.th/nwpapi/v1/forecast/area/place"

    querystring = {
        "domain": "2", 
        "province": "ประทุมธานี", 
        "amphoe": "คลองหลวง", 
        "fields": "tc,rh", 
        "starttime": formatted_date + "T" + formatted_time
    }

    headers = {
        'accept': "application/json",
        'authorization': "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjRhM2ZmNDBlNTBjMWY0MWFjZjZmYzVmZDQ2N2VkODBkOTdiZmE0NTE2NDU1NTU2ZmVhOTFmM2NhMjE4ODMxODYwODhlNzUyYmYyODY2NmMxIn0.eyJhdWQiOiIyIiwianRpIjoiNGEzZmY0MGU1MGMxZjQxYWNmNmZjNWZkNDY3ZWQ4MGQ5N2JmYTQ1MTY0NTU1NTZmZWE5MWYzY2EyMTg4MzE4NjA4OGU3NTJiZjI4NjY2YzEiLCJpYXQiOjE3MTE0MzcyNDMsIm5iZiI6MTcxMTQzNzI0MywiZXhwIjoxNzQyOTczMjQzLCJzdWIiOiIyMzk5Iiwic2NvcGVzIjpbXX0.rSst5_Xa8b3bqVNd82H9MH--FgwYBpIFPfgkFavrBz1wncBCMGuzXWTOZAuZrvhS9SqwRVxbR-R3CHmyaqFsx_euiHkqnS1MazQhvlyVeQo9aeNweK-GjaM9RBCwcTku9FNX_q5FLtkyQx9PtOQa0PzpR-Fu8o5Oyguo0uwCyJulVyEMvwZRdiJspe5TnKy_4mWuzqi0hXaumxNmVFOXGuo4h8yC71RgAy9x0rJv9Fs3wgUVV1tExvAHiopqs-4jpJzaZkiKIUEAy4MgsfQFPbXm2fogsUxxuxL8n-_9pSHzzf7lR8CQRfQ_aqLozIygFiomFjbddjdKCstxc-ewM_MQuYMLLPIm8vy5y18aFwPaJAZRsiq6raR95gXCOae1QAgRPs3HZNxHHNAZVWShpe0l14xRu6Su7OMC7qhaDanpRQGiFHKZfNrIgwhLM2A8fMvSrQjBw8Flj3RRyjpzfLGUbTt8YYweUc3OM1ukTrHKdI8GnksBHlwrxQZqZkpkOVmmM0t6IaBP-28IdkJSxvP_TMx6lVEhE3N3HNbGM_4kMvOSebKfNIrJwVCAsqzpYkk5URGCrnRcExXnxkDQjErCmSbRNtJsLofTGCfRI6hXH-QOgi1uqPE_DlDeml-dJ2J3zSYHFPzrahRzDYSWdnXKtmvJAibv-bgu2Nmuxm0"
    }

    response = requests.request("GET", url, headers=headers, params=querystring)
    data = response.json()

    # ตรวจสอบว่ามีข้อมูลอุณหภูมิและความชื้นหรือไม่
    if 'WeatherForecasts' in data and len(data['WeatherForecasts']) > 0:
        forecast_data = data['WeatherForecasts'][0]
        temperature = forecast_data.get('tc')
        humidity = forecast_data.get('rh')
        
        if temperature is not None and humidity is not None:
            print(f'Temperature: {temperature}°C')
            print(f'Humidity: {humidity}%')
        else:
            print('Failed to retrieve temperature and humidity data.')
    else:
        print('No weather forecast data available.')

get_weather()
