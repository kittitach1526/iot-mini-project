import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# ดาวน์โหลดข้อมูลบัญชีเซอร์วิส
cred = credentials.Certificate("admin.json")

# เริ่มต้นแอป Firebase
firebase_admin.initialize_app(cred)

# เชื่อมต่อกับ Firestore
db = firestore.client()

# ตัวอย่างการใช้งาน: เพิ่มเอกสารใหม่ในคอลเล็กชัน "users"
# doc_ref = db.collection(u'user').document(u'admin')
# doc_ref.set({
#     u'user': u'admin',
#     u'password': u'admin',
#     u'role': u'admin'
# })


docs = db.collection('user').get()

for doc in docs:
    print(type(doc.to_dict()))
    print(doc.id, doc.to_dict())



class user :

    def __init__(self) -> None:
        pass

    def get_user(username):
        
        doc_ref = db.collection(u'user').document(username)
        print(doc_ref)
        return doc_ref