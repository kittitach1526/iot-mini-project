import firebase_admin
from firebase_admin import credentials, firestore, db

# กำหนด path ไฟล์ service account key (.json) สำหรับ Firebase Admin SDK
cred = credentials.Certificate("admin.json")

# กำหนดชื่อโปรเจคใน Firebase และเข้าถึง Firestore และ Realtime Database
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://database-iot-python-default-rtdb.asia-southeast1.firebasedatabase.app/',
    'projectId': 'database-iot-python'
})

# เชื่อมต่อ Firestore
firestore_db = firestore.client()

# เชื่อมต่อ Realtime Database
realtime_db = db.reference('/')

doc_ref = firestore_db.collection(u'user').document(u'admin')
data_doc =doc_ref.get()
print(data_doc.to_dict())

# ตัวอย่างการใช้งาน Firestore
data = realtime_db.get()
print(data)