data_role = ""
user = ""

#Line notify Token 
line_token = "l6zjh6mZJhOV2cWgIkUDYuFLULVRT1uQUok7131rdtg"
