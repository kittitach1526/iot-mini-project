
#Version 1.0 

from flask import Flask, render_template ,url_for, jsonify,request
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import db
import Role
# import datetime
from firebase_admin.firestore import SERVER_TIMESTAMP
import time
# import send_line
import requests

# import realtime
cred = credentials.Certificate("admin.json")
# firebase_admin.initialize_app(cred)
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://database-iot-python-default-rtdb.asia-southeast1.firebasedatabase.app/',
    'projectId': 'database-iot-python'
})



firestore_db = firestore.client()
realtime_db = db.reference('/')

app = Flask(__name__)

def send_line_notification(message):
    url = 'https://notify-api.line.me/api/notify'
    headers = {
        'Authorization': 'Bearer ' + Role.line_token
    }
    data = {
        'message': message,
    }
    response = requests.post(url, headers=headers, data=data)
    if response.status_code == 200:
        print('Notification sent successfully!')
    else:
        print('Failed to send notification. Status code:', response.status_code)

@app.route('/')
def home():    
    return render_template("index.html")

@app.route('/login',methods = ["POST"])
def login():
    # message = "มีการ Login admin  "
    # #send_line_notification(message)
    user = request.form.get('user')
    password = request.form.get('password')
    # print(user,password)

    doc_ref = firestore_db.collection(u'user').document(user)
    data_doc =doc_ref.get()
    print(data_doc.to_dict())
    
    if user == data_doc.to_dict()['user'] and password == data_doc.to_dict()['password'] :
        Role.data_role = data_doc.to_dict()['role']
        Role.user = data_doc.to_dict()['user']
        print("role :",Role.data_role)

        msg_to_line = "มีการ Login ! \n User : "+Role.user
        send_line_notification(msg_to_line)

        if data_doc.to_dict()['role'] == "admin" : 
            docs = firestore_db.collection('user').get()
            data_list = []
            for doc in docs:
                # print(type(doc.to_dict()))
                data_list.append(doc.to_dict())
                # print(data_list)
            return render_template('welcome_admin.html', data = data_list)
        else :
            data_realtime = realtime_db.get()
            
            query = firestore_db.collection(u'log').order_by(u'timestamp', direction=firestore.Query.DESCENDING).limit(15)

            # ดึงข้อมูล
            results = query.get()
            # พิมพ์ข้อมูลที่ดึงได้
            log = []
            for result in results:
                data = result.to_dict()
                timestamp = data.get('timestamp').second
                formatted_timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
                # print("Data:", data)
                # print("Timestamp:", formatted_timestamp)
                # print(type(formatted_timestamp))
                data['timestamp'] = formatted_timestamp
                # print(data)
                log.append(data)

            #     print(log)
            # print(data)
            if data_realtime['switch1'] == 1 :
                data_realtime['switch1'] = "ON"


            if data_realtime['switch1'] == 0:
                data_realtime['switch1'] = "OFF"

            if data_realtime['switch2'] == 1:
                data_realtime['switch2'] = "ON"

            if data_realtime['switch2'] == 0 :
                data_realtime['switch2'] = "OFF"
            return render_template('dashboard.html',data = data_realtime,log = log)
    else :
        return render_template('index.html')

@app.route('/add_click', methods = ["POST"])
def add_click():
    # realtime_db = db.reference('/')
    command  = request.form.get('button_nav')
    # print(command)
    if(command == "add_user"):
        return render_template('add.html')
    elif(command == "dashboard"):
        data_realtime = realtime_db.get()

        
        query = firestore_db.collection(u'log').order_by(u'timestamp', direction=firestore.Query.DESCENDING).limit(15)

        # ดึงข้อมูล
        results = query.get()
        # พิมพ์ข้อมูลที่ดึงได้
        log = []
        for result in results:
            data = result.to_dict()
            timestamp = data.get('timestamp').second
            formatted_timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
            # print("Data:", data)
            # print("Timestamp:", formatted_timestamp)
            # print(type(formatted_timestamp))
            data['timestamp'] = formatted_timestamp
            # print(data)
            log.append(data)

        if data_realtime['switch1'] == 1 :
            data_realtime['switch1'] = "ON"


        if data_realtime['switch1'] == 0:
            data_realtime['switch1'] = "OFF"

        if data_realtime['switch2'] == 1:
            data_realtime['switch2'] = "ON"

        if data_realtime['switch2'] == 0 :
            data_realtime['switch2'] = "OFF"

        #     print(log)
        # print(data)
        return render_template('dashboard.html',data = data_realtime,log = log)
        
    elif(command == "logout"):
        Role.data_role = ""
        Role.user=""
        print("clear role ")
        return render_template('index.html')
    
    else:
        return "Error Command"

@app.route('/switch', methods = ['POST'])
def switch_control():
    command = request.form.get('switch')
    
    try : 
        # current_time = datetime.datetime.now()
        # formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        # print(type(formatted_time))
        # print("เวลาปัจจุบันเป็นสตริง:", formatted_time)
        # doc_log = firestore_db.collection(u'log').document(formatted_time)
        # doc_log.set({'user':"test",
        #              'time':formatted_time,
        #              'Action':command
        #              })
        
        # สร้างข้อมูลที่ต้องการเพิ่ม
        data = {
            u'user': Role.user,
            u'role': Role.data_role,
            u'action': command,
            u'timestamp': SERVER_TIMESTAMP
        }

        # เพิ่มข้อมูลลงใน collection ที่ชื่อว่า 'users'
        firestore_db.collection(u'log').add(data)
        
        # result_ref = firestore_db.collection(u'log').get()
        # result = result_ref.to_dict()
        # print('result :',result)
    except :
        print("time error ")
        pass

    # message_to_line ="มีการใช้คำสั่ง !\n User:"+Role.user+"\n Commande : "+command
    # send_line_notification(message_to_line)


    if command == "sw1_on" :
        data = {'switch1':1}
        realtime_db.update(data)
        
    elif command == "sw1_off" :
        data = {'switch1':0}
        realtime_db.update(data)
        

    if command == "sw2_on" :
        data = {'switch2':1}
        realtime_db.update(data)
        
    elif command == "sw2_off" :
        data = {'switch2':0}
        realtime_db.update(data)

    if command == "sw3_on" :
        data = {'switch3':1}
        realtime_db.update(data)
        
    elif command == "sw3_off" :
        data = {'switch3':0}
        realtime_db.update(data)

    if command == "sw4_on" :
        data = {'switch4':1}
        realtime_db.update(data)
        
    elif command == "sw4_off" :
        data = {'switch4':0}
        realtime_db.update(data)
        
    data_realtime = realtime_db.get()
    
    print("check role :",Role.data_role)
    if Role.data_role == "admin":
        data_realtime = realtime_db.get()

        
        query = firestore_db.collection(u'log').order_by(u'timestamp', direction=firestore.Query.DESCENDING).limit(15)

        # ดึงข้อมูล
        results = query.get()
        # พิมพ์ข้อมูลที่ดึงได้
        log = []
        for result in results:
            data = result.to_dict()
            timestamp = data.get('timestamp').second
            formatted_timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
            # print("Data:", data)
            # print("Timestamp:", formatted_timestamp)
            # print(type(formatted_timestamp))
            data['timestamp'] = formatted_timestamp
            # print(data)
            log.append(data)

        #     print(log)
        # print(data)
            
        message_to_line = "Command : "+command+" \n User : "+Role.user
        send_line_notification(message_to_line)


        print(data_realtime)
                #print(data_realtime)
        
        if data_realtime['switch1'] == 1 :
            data_realtime['switch1'] = "ON"


        if data_realtime['switch1'] == 0:
            data_realtime['switch1'] = "OFF"

        if data_realtime['switch2'] == 1:
            data_realtime['switch2'] = "ON"

        if data_realtime['switch2'] == 0 :
            data_realtime['switch2'] = "OFF"



        # print(type(data_realtime['switch1']))

        return render_template('dashboard.html',data = data_realtime,log = log)
    if Role.data_role == "user" : 
        data_realtime = realtime_db.get()

        
        query = firestore_db.collection(u'log').order_by(u'timestamp', direction=firestore.Query.DESCENDING).limit(15)

        # ดึงข้อมูล
        results = query.get()
        # พิมพ์ข้อมูลที่ดึงได้
        log = []
        for result in results:
            data = result.to_dict()
            timestamp = data.get('timestamp').second
            formatted_timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
            # print("Data:", data)
            # print("Timestamp:", formatted_timestamp)
            # print(type(formatted_timestamp))
            data['timestamp'] = formatted_timestamp
            # print(data)
            log.append(data)

            print(log)
        # print(data)
            
        message_to_line = "Command : "+command+" \n User : "+Role.user
        send_line_notification(message_to_line)

        print(data_realtime)

        if data_realtime['switch1'] == 1 :
            data_realtime['switch1'] = "ON"


        if data_realtime['switch1'] == 0:
            data_realtime['switch1'] = "OFF"

        if data_realtime['switch2'] == 1:
            data_realtime['switch2'] = "ON"

        if data_realtime['switch2'] == 0 :
            data_realtime['switch2'] = "OFF"

        # print(type(data_realtime['switch1']))


        print(message_to_line)
        return render_template('dashboard.html',data = data_realtime,log = log)


@app.route('/check_add', methods = ["POST"])
def check_add():
    user = request.form.get('user')
    password = request.form.get('password')
    role = request.form.get('role')

    user_data = {
        "user": user,
        "password": password,
        "role":role
    }
    add = firestore_db.collection(u'user').document(user)
    add.set(user_data)

    docs = firestore_db.collection('user').get()
    data_list = []
    for doc in docs:
        # print(type(doc.to_dict()))
        data_list.append(doc.to_dict())
        # print(data_list)
    
    return render_template('welcome_admin.html', data = data_list)

@app.route('/delete' ,methods=["POST"])
def delete_user():
    user = request.form.get('button_delete')

    add = firestore_db.collection(u'user').document(user)
    add.delete()

    docs = firestore_db.collection('user').get()
    data_list = []
    for doc in docs:
        # print(type(doc.to_dict()))
        data_list.append(doc.to_dict())
        # print(data_list)
    
    return render_template('welcome_admin.html', data = data_list)

@app.route('/api/get_soil', methods=['GET'])
def get_soil():
    data_realtime = realtime_db.get()
    soil = str(data_realtime['push'])
    return jsonify({'soil': soil})


if __name__ =="__main__":
    app.run(debug=True)